package models;

public class Reservation 
{
	private long cin;
	private Repat repat;
	
	public long getCin() 
	{
		return cin;
	}
	
	public void setCin(long cin) 
	{
		this.cin = cin;
	}
	
	public Repat getRepat() 
	{
		return repat;
	}
	
	public void setRepat(Repat repat) 
	{
		this.repat = repat;
	}
}
